
import 'package:flutter/material.dart';

void main() => runApp(const NotaApp());

class NotaApp extends StatelessWidget {
  const NotaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nota Toko')),
      body: ListView(
        children: const [
          ListTile(title: Text('Dashboard')),
          ListTile(title: Text('Barang')),
          ListTile(title: Text('Pelanggan')),
          ListTile(title: Text('Nota')),
          ListTile(title: Text('Pengaturan Toko')),
        ],
      ),
    );
  }
}
